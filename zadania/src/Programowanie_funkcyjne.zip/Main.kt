fun main()
{
    zad1();
    zad2();
    zad4();
    zad6();
    zad7();
    zad8();
}
